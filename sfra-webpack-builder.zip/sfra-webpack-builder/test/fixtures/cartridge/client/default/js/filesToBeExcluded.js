"use strict";

console.log("Hi there! this file not be compiled");
