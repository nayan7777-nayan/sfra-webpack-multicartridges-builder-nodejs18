"use strict";

console.log("Hi there!");
